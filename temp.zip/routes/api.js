const express = require('express');
const router = express.Router();
const Ninja=require('./models/users.js');
router.get('/',function(req,res){
  res.send({type:'get'});
});

router.get('/ninjas/:id',function(req,res){
  Ninja.findById({_id:req.params.id}).exec(function(err,ninja){
    if(err){
      console.log('error:'+err)
    }else{
      res.json(ninja);
    }
  });
});
router.get('/ninjas',function(req,res){
  Ninja.find({}).exec(function(err,ninja){
    if(err){
      console.log('error:'+err)
    }else{
      res.json(ninja);
    }
  });
});
router.post('/ninjas',function(req,res,next){
  Ninja.create(req.body).then(function(err,ninja){
    if(err){
      res.send(err);
    }else{
res.send(ninja)};
  }).catch(next);
});
router.put('/ninjas/:id',function(req,res,next){
  Ninja.findByIdAndUpdate({_id:req.params.id},req.body,{new:true}).then(function(ninja){
      res.send(ninja);
  }).catch(next);
});
router.delete('/ninjas/:id',function(req,res,next){
  Ninja.findByIdAndRemove({_id:req.params.id}).then(function(ninja){
      res.send(ninja);
  }).catch(next);

});
module.exports = router;
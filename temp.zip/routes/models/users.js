const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const bcrypt=require('bcrypt');

const studySchema=new Schema({
    school:{type:String,default:'engineering'},
    course:{type:String,default:'robotics'},
    units:{type:String,defult:'23'}
    
});
  const UserSchema=new Schema({
    name:{type:String,required:[true,'please enter name']},
    gender:{type:String},
    age:{type:String},
    study:studySchema
});

// UserSchema.methods.generateHash = function(password){
// return bcrypt.hashSync(password,bcrypt.genSaltSync(9));
// };
// UserSchema.methods.validPassword=function(password){
// return bcrypt.compareSync(password,this.password);
// };
const User=mongoose.model('user',UserSchema);
module.exports=User;